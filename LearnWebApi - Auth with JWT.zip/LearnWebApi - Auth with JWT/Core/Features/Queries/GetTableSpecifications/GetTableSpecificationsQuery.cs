using MediatR;
using Core.Features.Queries.GetTableSpecifications;

namespace Core.Features.Queries.GetTableSpecifications
{
    public class GetTableSpecificationsQuery : IRequest<GetTableSpecificationsResponse>
    {
        public Guid TableSpecificationId { get; set; }
    }
}