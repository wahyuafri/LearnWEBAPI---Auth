using MediatR;
using Core;
using Microsoft.Extensions.Caching.Distributed;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Persistence.Repositories;
using Core.Services;
using Persistence.Models;

namespace Core.Features.Queries.GetTableSpecifications
{
    public class GetTableSpecificationsHandler : IRequestHandler<GetTableSpecificationsQuery, GetTableSpecificationsResponse>
    {
        private readonly ITableSpecificationRepository _tableSpecificationRepository;
        private readonly RedisService<TableSpecification> _redisService;

        public GetTableSpecificationsHandler(ITableSpecificationRepository tableSpecificationRepository, RedisService<TableSpecification> redisService)
        {
            _tableSpecificationRepository = tableSpecificationRepository;
            _redisService = redisService;
        }

        public async Task<GetTableSpecificationsResponse> Handle(GetTableSpecificationsQuery query, CancellationToken cancellationToken)
        {
            var cacheKey = $"TableSpecification_{query.TableSpecificationId}";

            string redisKey = $"TableSpecification:{query.TableSpecificationId}";
            //var tableSpecification = _tableSpecificationRepository.GetById(query.TableSpecificationId);
            var tableSpecification = await _redisService.GetDataAsync(redisKey, await _tableSpecificationRepository.GetByIdAsync(id: query.TableSpecificationId));

            if (tableSpecification is null)
                return new GetTableSpecificationsResponse();

            var response = new GetTableSpecificationsResponse()
            {
                TableId = tableSpecification.TableId,
                ChairNumber = tableSpecification.ChairNumber,
                TableNumber = tableSpecification.TableNumber,
                TablePic = tableSpecification.TablePic,
                TableType = tableSpecification.TableType
            };

            return response;
        }
    }
}