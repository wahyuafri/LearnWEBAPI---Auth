using Persistence.Models;
using System;
using System.Threading.Tasks;

namespace Persistence.Repositories
{
    public interface ITableSpecificationRepository : IGenericRepository<TableSpecification>
    {
    }
}
