﻿using System.ComponentModel.DataAnnotations;

namespace Core.Features.Commands.UpdateTableSpecification
{
    public class UpdateTableSpecificationResponse
    {
        [Required]
        public Guid TableId { get; set; }
        public int TableNumber { get; set; }
        public int ChairNumber { get; set; }
        [Required]
        public string TablePic { get; set; }
        public string? TableType { get; set; }
    }
}