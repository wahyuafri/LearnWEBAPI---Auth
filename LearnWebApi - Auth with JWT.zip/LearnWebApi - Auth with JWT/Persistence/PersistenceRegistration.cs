using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Persistence.DatabaseContext;
using Persistence.Repositories;
using Microsoft.Extensions.Caching.StackExchangeRedis;
using StackExchange.Redis;

namespace Persistence
{
    public static class PersistenceRegistration
    {
        public static IServiceCollection AddPersistenceServices(this IServiceCollection services)
        {
            const string dbConnection = "Server=localhost;Database=Testdata;User=root;Password=;SslMode=None;";

            // Register MySQL database context
            services.AddDbContext<TableContext>(opt =>
                opt.UseMySql(dbConnection, ServerVersion.AutoDetect(dbConnection)));

            // Register the table specification repository
            services.AddScoped<ITableSpecificationRepository, TableSpecificationRepository>();

            return services;
        }

        public static IServiceCollection AddRedis(this IServiceCollection services)
        {
            const string redisConnString = "localhost:6379";

            // Add Redis cache configuration
            services.AddStackExchangeRedisCache(options =>
            {
                options.Configuration = redisConnString; // Update with your Redis server configuration
                options.InstanceName = "TableSpecifications:";
            });

            // Register the connection multiplexer as a singleton
            var redis = ConnectionMultiplexer.Connect(redisConnString);
            services.AddSingleton<IConnectionMultiplexer>(redis);

            return services;
        }
    }
}