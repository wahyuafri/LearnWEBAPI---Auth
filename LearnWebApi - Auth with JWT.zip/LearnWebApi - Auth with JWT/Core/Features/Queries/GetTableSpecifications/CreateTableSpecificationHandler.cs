﻿using System.ComponentModel.Design;
using Core.Services;
using MediatR;
using Persistence.Models;
using Persistence.Repositories;
using StackExchange.Redis;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Core.Features.Commands.CreateTableSpecification
{
    public class CreateTableSpecificationHandler : IRequestHandler<CreateTableSpecificationCommand, CreateTableSpecificationResponse>
    {
        private readonly ITableSpecificationRepository _tableSpecificationRepository;
        private readonly RedisService<TableSpecification> _redisService;
        

        public CreateTableSpecificationHandler(ITableSpecificationRepository tableSpecificationRepository, RedisService<TableSpecification> redisService)
        {
            _tableSpecificationRepository = tableSpecificationRepository;
            _redisService = redisService;
        }

        public async Task<CreateTableSpecificationResponse> Handle(CreateTableSpecificationCommand command, CancellationToken cancellationToken)
        {
            var tableSpecification = new TableSpecification
            {
                TableId = new Guid(),
                TableNumber = command.TableNumber,
                ChairNumber = command.ChairNumber,
                TablePic = command.TablePic,
                TableType = command.TableType
            };
            string redisKey = $"TableSpecification:{tableSpecification.TableId}";
            await _tableSpecificationRepository.AddAsync(tableSpecification);
            await _redisService.CreateDataAsync(redisKey, await _tableSpecificationRepository.GetByIdAsync(id: tableSpecification.TableId));

            return new CreateTableSpecificationResponse
            {
                TableId = command.TableId,
                TableNumber = command.TableNumber,
                ChairNumber = command.ChairNumber,
                TablePic = command.TablePic,
                TableType = command.TableType
            };
        }
    }
}